import Hero from "../components/Hero"

function Home() {
  return (
    <div>
        <Hero/>
    </div>
  )
}

export default Home