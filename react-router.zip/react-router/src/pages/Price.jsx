
function Price() {
  return (
    <div>Price</div>
  )
}

export default Price