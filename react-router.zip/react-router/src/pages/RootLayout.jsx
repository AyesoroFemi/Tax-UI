import { Outlet } from "react-router"
import Navbar from '../components/Navbar'
function RootLayout() {
  return (
    <div>
        <Navbar />
        <Outlet/>
        <h1>Hello I am a footer!!!</h1>
    </div>
  )
}

export default RootLayout