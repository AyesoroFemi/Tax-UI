
function About() {
  return (
    <div>
        <h1>Hello I am about Page!!!</h1>
    </div>
  );
}

export default About;
