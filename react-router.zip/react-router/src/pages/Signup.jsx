
function Signup() {
  return (
    <div>
        <h1>I am signup page</h1>
    </div>
  )
}

export default Signup