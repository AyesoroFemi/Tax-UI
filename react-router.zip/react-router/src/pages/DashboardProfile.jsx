
function DashboardProfile() {
  return (
    <div>DashboardProfile</div>
  )
}

export default DashboardProfile