
function Feature() {
  return (
    <div>Feature</div>
  )
}

export default Feature