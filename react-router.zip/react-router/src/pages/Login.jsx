
function Login() {
    return (
      <div>
          <h1>I am login page</h1>
      </div>
    )
  }
  
  export default Login