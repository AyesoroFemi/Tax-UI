import { Outlet } from "react-router"
import { Link } from "react-router-dom"

function DashboardLayout() {
  return (
    <div>
        <div>
        <Link to="/dashboard">Dashboard Home</Link>
        <Link to="/dashboard/stats">Stats</Link>
        <Link to="/dashboard/profile">Profile</Link>
        <a href="#">Become a Software Engineer</a>
        <button>View & Select Engineer</button>
      </div>
        <Outlet/>
    </div>
  )
}

export default DashboardLayout