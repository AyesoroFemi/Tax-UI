
function Hero() {
  return (
    <div>
        <h1>Hello I am hero page!!!</h1>
    </div>
  )
}

export default Hero