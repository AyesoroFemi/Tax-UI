import { Link } from 'react-router-dom';
import DecagonLogo from '../assets/decagon-logo.svg' 

import './Navbar.css'
export default function Navbar() {
    console.log('Hello I am a javascript file')
   

  return (
    <div className='nav'>
      <img src={DecagonLogo} alt="" />
      <div>
        <Link to="/">Home</Link>
        <Link to="/about">About</Link>
        <Link to="/price">Price</Link>
        <Link to="/feature">Features</Link>
        <a href="#">Become a Software Engineer</a>
        <button>View & Select Engineer</button>
      </div>
    </div>
  );
}

