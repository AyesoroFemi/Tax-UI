// import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'

import './App.css'
import Home from './pages/Home'
import About from './pages/About'
import Price from './pages/Price'
import Feature from './pages/Feature'
// import Navbar from './components/Navbar'
import RootLayout from './pages/RootLayout'
import Login from './pages/Login'
import Signup from './pages/Signup'
import DashboardLayout from './pages/DashboardLayout'
import DashboardStats from './pages/DashboardStats'
import DashboardProfile from './pages/DashboardProfile'
import DashboardHome from './pages/DashboardHome'


const router = createBrowserRouter([
    {
      path: '/',
      element: <RootLayout />,
      children: [
        {
          path: '/',
          element: <Home />
        },
        {
          path: 'about',
          element: <About />
        },
        {
          path: 'price',
          element: <Price />
        },
        {
          path: 'feature',
          element: <Feature />
        }
      ]
    
    },
    {
      path: '/login',
      element: <Login/>
    },
    {
      path: '/signup',
      element: <Signup/>
    },
    {
      path: '/dashboard',
      element: <DashboardLayout />,
      children: [
        {
          path: '/dashboard',
          element: <DashboardHome />
        },
        {
          path: 'stats',
          element: <DashboardStats />
        },
        {
          path: 'profile',
          element: <DashboardProfile/>
        }
      ]
    }
])

function App() {


  return (
    <RouterProvider router={router}/>
    // <Router>
    //   <Navbar />
    //   <Routes>
    //     <Route path="/" element={<Home />}/>
    //     <Route path="/about" element={<About />}/>
    //     <Route path="/price" element={<Price />}/>
    //     <Route path="/feature" element={<Feature />}/>
    //   </Routes>
    // </Router>
  )
}

export default App
