
import './App.css'
import MainHero, { Hero, HeroNavigation, HeroSection } from './components/Hero'
import Navbar from './components/Navbar'

function App() {

  // const name = "Emmanuel Fabian"

  return (
    <>
      {/* <h1>{name}</h1>
      <h1>{ 10 * 790}</h1> */}
      <Navbar/>
      <Hero />
      <HeroSection />
      <HeroNavigation/>
      <MainHero/>
    </>
  )
}

export default App
