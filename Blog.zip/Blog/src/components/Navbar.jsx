import DecagonLogo from '../assets/decagon-logo.svg' 

import './Navbar.css'
export default function Navbar() {
    console.log('Hello I am a javascript file')
   

  return (
    <div className='nav'>
      <img src={DecagonLogo} alt="" />
      <div>
        <a href="#">Become a Software Engineer</a>
        <button>View & Select Engineer</button>
      </div>
    </div>
  );
}

