/* eslint-disable react/prop-types */

function People({people}) {
  return (
    <div  style={{ display: "flex" }}>
        {people.map((person) => {
            return (
                <div className="container" key={person.id}>
                    <h1>{person.name}</h1>
                    <p>{person.profession}</p>
                </div>
            )
        })}
    </div>
  )
}

export default People