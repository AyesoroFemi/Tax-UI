import List from "./List";
import People from "./People";

export function Hero() {
  return <h1>I am a named export!!!</h1>;
}
export function HeroSection() {
  return <h1>I am a named exportSection!!!</h1>;
}
export function HeroNavigation() {
  return <h1>I am a named export HeroNavigation!!!</h1>;
}

function MainHero() {
  const people = [
    {
      id: 0,
      name: "Creola Katherine Johnson",
      profession: "mathematician",
    },
    {
      id: 1,
      name: "Mario José Molina-Pasquel Henríquez",
      profession: "chemist",
    },
    {
      id: 2,
      name: "Mohammad Abdus Salam",
      profession: "physicist",
    },
    {
      id: 3,
      name: "Percy Lavon Julian",
      profession: "chemist",
    },
    {
      id: 4,
      name: "Subrahmanyan Chandrasekhar",
      profession: "astrophysicist",
    },
  ];
  const person = {
    name: "Godwin",
    location: "Lagos",
    age: 45,
  };
  const person1 = {
    name: "Fabian",
    location: "USA",
    age: 56,
  };
  const person2 = {
    name: "Gabin",
    location: "Abuja",
    age: 20,
  };

  // const {name, location, age } = person

  return (
    <>
      <div style={{ display: "flex" }}>
        <List lists={person} />
        <List lists={person1} />
        <List lists={person2} />
      </div>
     <People people={people} />
    </>
  );
}

export default MainHero;
