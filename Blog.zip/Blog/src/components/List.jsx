/* eslint-disable react/prop-types */

function List({ lists }) {
    const {name, location, age} = lists
  return (
    <div className="container">
        <h1>{name}</h1>
        <h1>{location}</h1>
        <h1>{age}</h1>
    </div>
  )
}

export default List